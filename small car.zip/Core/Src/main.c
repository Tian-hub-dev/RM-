/* USER CODE BEGIN Header */

/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "tim.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "oled.h"
#include "stdio.h"
#include "motor.h"
#include "pid.h"
#include <string.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
#define AHEAD 0
#define LEFT   1
#define LLEFT  2
#define LLLEFT 3
#define LLLLEFT 4

#define RIGHT    -1
#define RRIGHT   -2
#define RRRIGHT  -3
#define RRRRIGHT  -4



extern float V1 ;
extern float V2 ;

int Motor1Pwm;
int Motor2Pwm;

extern tPid pidV1;
extern tPid pidV2;

uint8_t OledString[20];//�洢����ʾ���ַ������ݣ�max 20 �ֽڣ�
extern float Mileage;//���

extern tPid pidHW_Tracking;//����ѭ����PID

uint8_t HW_Read[4] = {0};//�������Թܵ�ƽ������     Global Unsigned Char Array
int8_t ThisState = 0;//���״̬  ȫ��ֻ��������g_+const��
int8_t LastState = 0; //�ϴ�״̬
int8_t turn_error=0;
static int R_S=0;

float PID_error;//����Թ�PID��������ٶ�       
float PID_V1;//���1�����ѭ��PID�����ٶ�    ȫ�ָ��������g_+Float��
float PID_V2;//���2
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_TIM4_Init();
  MX_ADC2_Init();
  /* USER CODE BEGIN 2 */
  OLED_Init();			//��ʼ��OLED
  OLED_Clear(); 
  
  HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_1);//PWM����
  HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_4);
  
  HAL_TIM_Encoder_Start(&htim2,TIM_CHANNEL_ALL);//����������
  HAL_TIM_Encoder_Start(&htim4,TIM_CHANNEL_ALL);
  
  HAL_TIM_Base_Start_IT(&htim2);				//��ʱ���ж�����
  HAL_TIM_Base_Start_IT(&htim4);                
  HAL_TIM_Base_Start_IT(&htim1);                
  
  PID_init();                     //��ʼ�� PID
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {

	  if(R_S==1)
{
	
	if(READ_HW_OUT_2==1||READ_HW_OUT_3==1)
	{
	R_S=0;
	}
}
   
	  
if(R_S==0)
{
	HW_Read[0] = READ_HW_OUT_1;
	HW_Read[1] = READ_HW_OUT_2;
	HW_Read[2] = READ_HW_OUT_3;
	HW_Read[3] = READ_HW_OUT_4;
}

	// sprintf((char*)OledString, "V1:%.2f", V1);//���ݸ�ʽ��Ϊ�ַ���
	// OLED_ShowString(0,0,OledString,12);//�������ٶ�
	// sprintf((char*)OledString, "V2:%.2f",V2);
	// OLED_ShowString(0,1,OledString,12);
	  
	//  sprintf((char*)OledString, "%d", HW_Read[0]);//����1.2.3.4
	// OLED_ShowString(0,3,OledString,12);
	// sprintf((char*)OledString, "%d", HW_Read[1]);
	// OLED_ShowString(0,4,OledString,12);
	// sprintf((char*)OledString, "%d", HW_Read[2]);
	// OLED_ShowString(0,5,OledString,12);
	// sprintf((char*)OledString, "%d", HW_Read[3]);
	// OLED_ShowString(0,6,OledString,12);
	
	
	
	  
//	static int lost_cnt = 0;
//static int is_turning = 0; // 标记是否处于转弯阶段

//// 先判断是否处于直角转弯的传感器组合
//if ((HW_Read[0] == 0&&HW_Read[1] == 1&&HW_Read[2] == 1&&HW_Read[3] == 1)||(HW_Read[0] == 0&&HW_Read[1] == 0&&HW_Read[2] == 1&&HW_Read[3] == 1)||(HW_Read[0] == 0&&HW_Read[1] == 0&&HW_Read[2] == 1&&HW_Read[3] == 1)||(HW_Read[0] == 1&&HW_Read[1] == 1&&HW_Read[2] == 0&&HW_Read[3] == 0)) {
//    is_turning = 1; // 进入转弯阶段
//}

//if(HW_Read[0]==0 && HW_Read[1]==0 && HW_Read[2]==0 && HW_Read[3]==0)
//{
//    lost_cnt++;
//    if (is_turning) {
//        // 转弯时丢信号：强制保持“转弯所需的方向”（比如直角转弯需要RRIGHT）
//        ThisState = (LastState>0) ? LLLLEFT : RRRRIGHT;  // 或根据实际转弯方向设为LEFT等
//    } else if (lost_cnt < 5) {
//        ThisState = LastState; // 原逻辑：非转弯时保持上次方向
//    } else {
//        ThisState = (LastState>0) ? LLLLEFT : RRRRIGHT; // 原逻辑：超次数切换
//    }
//} else {
//    lost_cnt = 0;
//    is_turning = 0; // 传感器恢复信号，退出转弯标记
//}

    if(HW_Read[0]==0 && HW_Read[1]==0 && HW_Read[2]==0 && HW_Read[3]==0)
    {
		if(LastState==RRRIGHT||LastState==RRRRIGHT||LastState==LLLEFT||LastState==LLLLEFT)
		{
			ThisState = LastState;
		}
		else    
		{
	        ThisState = AHEAD ;//
		}
		
    }
	
	
	else if(HW_Read[0] == 0&&HW_Read[1] == 1&&HW_Read[2] == 0&&HW_Read[3] == 0 )
	{
		ThisState = RIGHT ;//��
		R_S=1;
	}
	else if(HW_Read[0] == 1&&HW_Read[1] == 0&&HW_Read[2] == 0&&HW_Read[3] == 0 )
	{
		ThisState = RRIGHT;//����
		R_S=1;
	}
	else if(HW_Read[0] == 1&&HW_Read[1] == 1&&HW_Read[2] == 0&&HW_Read[3] == 0)
	{
		
		ThisState = RRRIGHT;//�����
				R_S=1;

	}
	else if(HW_Read[0] == 1&&HW_Read[1] == 1&&HW_Read[2] == 1)
	{
		
		ThisState = RRRRIGHT;//������
				R_S=1;

	}
	
	
	
	else if(HW_Read[0] == 0&&HW_Read[1] == 0&&HW_Read[2] == 1&&HW_Read[3] == 0 )
	{
		ThisState = LEFT;//��
		R_S=1;
	}
	else if(HW_Read[0] == 0&&HW_Read[1] == 0&&HW_Read[2] == 0&&HW_Read[3] == 1 )
	{
		ThisState = LLEFT;//����
		R_S=1;
	}
	else if(HW_Read[0] == 0&&HW_Read[1] == 0&&HW_Read[2] == 1&&HW_Read[3] == 1)
	{
		ThisState = LLLEFT;//�����
		R_S=1;

	}
	else if(HW_Read[1] == 1&&HW_Read[2] == 1&&HW_Read[3] == 1)
	{
		ThisState = LLLLEFT;//������
		R_S=1;
	}
	else
	{
		ThisState=LastState ;
	}
	
	
	
		
	
	
	switch(ThisState)
	{
		case  AHEAD:
			turn_error = 0;
			break;
		case LEFT:
			turn_error=1;
			break;
		case LLEFT:
			turn_error=2;
			break;
		case LLLEFT:
			turn_error=3;
			
			break;
		case LLLLEFT:
			turn_error=4;
			
			break;
		case RIGHT:
			turn_error=-1;
			break;
		case RRIGHT:
			turn_error=-2;
			break;
		case RRRIGHT:
			turn_error=-3;
			
			break;
		case RRRRIGHT:
			turn_error=-4;
			
			break;
	}

			
	
	PID_error = PID_realize(&pidHW_Tracking,turn_error);//PID�������Ŀ���ٶ� ����ٶȣ���ͻ����ٶȼӼ�

	PID_V1 = 3 + PID_error;//V1=�����ٶ�+PIDѭ������
	PID_V2 = 3 - PID_error;//V2=�����ٶ�-PIDѭ������
		
	if(PID_V1 >5) PID_V1 =5;//�޷� �޷��ٶ�0-5
	if(PID_V1 <0) PID_V1 =0;
	if(PID_V2 >5) PID_V2 =5;
	if(PID_V2 <0) PID_V2 =0;
	
	
	//����pwm ���� ��һ����û�����һ����
  
//if(ThisState != LastState)
//	{
  Speed_target(PID_V1,PID_V2);//ͨ��������ٶȿ��Ƶ��
//	}
	
	
	LastState = ThisState;//�����ϴκ���״̬	
	
		

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC;
  PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV6;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
